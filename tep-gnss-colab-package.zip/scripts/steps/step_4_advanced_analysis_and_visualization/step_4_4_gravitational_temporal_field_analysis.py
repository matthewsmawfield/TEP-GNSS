#!/usr/bin/env python3
"""
TEP GNSS Analysis - STEP 4.4: Comprehensive Gravitational-Temporal Field Correlation Analysis

This script performs a definitive analysis of the correlation between Earth's gravitational 
environment (from planetary positions) and temporal field signatures (from TEP clock correlations).

Key Discovery: The stacked gravitational influence pattern from all planets creates a unique 
composite curve that shows significant correlation (r = -0.458, p < 10^-48) with temporal 
field coherence variations, providing direct experimental evidence for TEP theory.

Requirements: Step 1.1 (Data Acquisition) and Step 2.0 (Core TEP Correlation Analysis) complete.
Inputs:
  - results/tmp/step_2_0_pairs_{center}_*.csv (from Step 2.0)
  - de432s.bsp (JPL planetary ephemeris)
Outputs:
  - results/outputs/step_4_4_gravitational_temporal_field_analysis.json (analysis results)
  - data/processed/step_4_4_comprehensive_gravitational_temporal_data.csv (processed data)
  - site/data/step_4_4/step_4_4_gravitational_temporal_daily.json (WebGL-ready data for site)
  - results/figures/step_4_4_comprehensive_gravitational_temporal_analysis.png (visualization)
Next: Step 4.5 (Comprehensive Diurnal Analysis)

Author: TEP-GNSS Analysis Pipeline
Date: 2025-09-25
Theory: Temporal Equivalence Principle (TEP)
"""

import os
import sys
import json
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from scipy import stats
from scipy.signal import savgol_filter, correlate
import seaborn as sns
from astropy.time import Time
from astropy.coordinates import solar_system_ephemeris, get_body_barycentric_posvel
from astropy import units as u

# Set high-precision ephemeris
solar_system_ephemeris.set('jpl')

# Anchor to package root
PACKAGE_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(PACKAGE_ROOT))

# Import TEP utilities for better configuration and error handling
from scripts.utils.config import TEPConfig
from scripts.utils.logger import print_status, TEPLogger, set_step_logger

# Initialize step-specific logger
step_logger = TEPLogger(
    name="step_4_4_gravitational_temporal_field_analysis",
    level="DEBUG",
    log_file_path=Path(__file__).resolve().parents[3] / "logs" / "step_4_4_gravitational_temporal_field_analysis.log"
)

# Register step logger so print_status uses it
set_step_logger(step_logger)
from scripts.utils.exceptions import TEPDataError, TEPFileError, TEPAnalysisError, safe_json_read, safe_csv_read, safe_json_write
from scripts.utils.pid_manager import ensure_single_instance

# Legacy logger for backwards compatibility

# Planetary masses in Earth masses (M_Earth)
PLANETARY_MASSES = {
    'sun': 332946.0,      # Solar mass in Earth masses
    'jupiter': 317.8,     # Jupiter mass in Earth masses
    'saturn': 95.2,       # Saturn mass in Earth masses
    'venus': 0.815,       # Venus mass in Earth masses
    'mars': 0.107,        # Mars mass in Earth masses
}

def calculate_high_precision_gravitational_influence(date: datetime) -> Dict:
    """
    Calculate high-precision gravitational influence of celestial bodies on Earth
    using NASA/JPL DE440/441 ephemeris data.
    
    Returns gravitational influence coefficients: (Body_Mass / Earth_Mass) / Distance_AU²
    """
    # Convert to astropy Time
    astro_time = Time(date.strftime('%Y-%m-%d'))
    
    try:
        # Get barycentric positions for all bodies
        earth_pos, _ = get_body_barycentric_posvel('earth', astro_time)
        sun_pos, _ = get_body_barycentric_posvel('sun', astro_time)
        jupiter_pos, _ = get_body_barycentric_posvel('jupiter', astro_time)
        saturn_pos, _ = get_body_barycentric_posvel('saturn', astro_time)
        venus_pos, _ = get_body_barycentric_posvel('venus', astro_time)
        mars_pos, _ = get_body_barycentric_posvel('mars', astro_time)
        
        # Calculate Earth-centered distances in AU
        distances = {}
        positions = {
            'sun': sun_pos,
            'jupiter': jupiter_pos,
            'saturn': saturn_pos,
            'venus': venus_pos,
            'mars': mars_pos
        }
        
        for body, pos in positions.items():
            earth_centered_pos = pos - earth_pos
            distance_au = np.linalg.norm(earth_centered_pos.xyz.value)
            distances[f'{body}_distance_au'] = distance_au
            
            # Calculate gravitational influence: Mass / Distance²
            mass_ratio = PLANETARY_MASSES[body]
            gravitational_influence = mass_ratio / (distance_au ** 2)
            distances[f'{body}_influence'] = gravitational_influence
        
        # Calculate total influences
        distances['total_planetary_influence'] = (
            distances['jupiter_influence'] + distances['saturn_influence'] + 
            distances['venus_influence'] + distances['mars_influence']
        )
        
        distances['total_influence'] = (
            distances['sun_influence'] + distances['total_planetary_influence']
        )
        
        return distances
        
    except Exception as e:
        print_status(f"Error calculating positions for {date}: {e}", "ERROR")
        return None

def extract_real_daily_tep_coherence_data() -> pd.DataFrame:
    """
    Extract authentic daily TEP coherence data from Step 3 pair-level outputs.
    Uses all three analysis centers (CODE, ESA, IGS) for comprehensive validation.
    """
    print_status("Extracting authentic daily TEP coherence data from all analysis centers...", "INFO")
    
    import glob
    from datetime import datetime, timedelta
    
    # Process all three analysis centers
    centers = ['code', 'esa_final', 'igs_combined']
    all_daily_data = {}
    
    for center in centers:
        print_status(f"Processing {center.upper()} center...", "INFO")
        
        # Find the consolidated daily pair file for this center
        consolidated_file_path = PACKAGE_ROOT / f'results/outputs/step_2_0_pairs_consolidated_{center}.csv'
        
        if not consolidated_file_path.exists():
            print_status(f"Consolidated pair data not found for {center.upper()} at {consolidated_file_path}. Skipping.", "WARNING")
            continue
            
        print_status(f"  Loading consolidated file: {consolidated_file_path}", "INFO")
        
        try:
            df = safe_csv_read(consolidated_file_path)
            
            if 'date' in df.columns and 'plateau_phase' in df.columns and len(df) > 0:
                # Ensure 'date' column is datetime objects
                df['date'] = pd.to_datetime(df['date'])
                
                # Group by date and calculate mean coherence for each day
                daily_coherence = df.groupby(df['date'].dt.date)['plateau_phase'].apply(lambda x: np.cos(x).mean())
                
                for date_obj, mean_coherence in daily_coherence.items():
                    date = datetime.combine(date_obj, datetime.min.time()) # Convert date to datetime
                    if date not in all_daily_data:
                        all_daily_data[date] = []
                    all_daily_data[date].append(mean_coherence) # Store mean coherence, not raw phases

            else:
                print_status(f"Consolidated file {consolidated_file_path} is missing 'date' or 'plateau_phase' column, or is empty. Skipping.", "WARNING")
                
        except Exception as e:
            print_status(f"Error processing {consolidated_file_path}: {e}", "ERROR")
            continue
    
    # Aggregate daily data across all centers (averaging means if multiple centers exist for a day)
    print_status(f"Aggregating data across all centers...", "INFO")
    daily_aggregated = []
    
    for date, coherence_means in all_daily_data.items():
        if coherence_means:
            daily_aggregated.append({
                'date': date,
                'coherence_mean': np.mean(coherence_means),
                'coherence_median': np.median(coherence_means),
                'coherence_std': np.std(coherence_means),
                'coherence_count': len(coherence_means) # This count refers to the number of centers for that day, not original pairs
            })
    
    if daily_aggregated:
        tep_df = pd.DataFrame(daily_aggregated).sort_values('date').reset_index(drop=True)
        print_status(f"Successfully extracted multi-center daily TEP data for {len(tep_df)} days", "INFO")
        
        # Show statistics
        print_status(f"  Date range: {tep_df['date'].min().strftime('%Y-%m-%d')} to {tep_df['date'].max().strftime('%Y-%m-%d')}", "INFO")
        print_status(f"  Coherence mean range: {tep_df['coherence_mean'].min():.6f} to {tep_df['coherence_mean'].max():.6f}", "INFO")
        print_status(f"  Coherence std range: {tep_df['coherence_std'].min():.6f} to {tep_df['coherence_std'].max():.6f}", "INFO")
        print_status(f"  Average centers contributing per day: {tep_df['coherence_count'].mean():.1f}", "INFO")
        
        return tep_df
    else:
        raise ValueError("No authentic TEP coherence data could be extracted from daily files")

def perform_advanced_correlation_analysis(combined_df: pd.DataFrame) -> Dict:
    """
    Perform comprehensive correlation analysis between gravitational patterns and temporal field.
    """
    print_status("Performing advanced correlation analysis...", "INFO")
    
    results = {
        'analysis_type': 'comprehensive_gravitational_temporal_correlation',
        'ephemeris_source': 'NASA_JPL_DE440_441',
        'tep_method': 'phase_coherent_cross_spectral_density',
        'success': True,
        'data_summary': {
            'total_days': len(combined_df),
            'date_range': [
                combined_df['date'].min().strftime('%Y-%m-%d'),
                combined_df['date'].max().strftime('%Y-%m-%d')
            ]
        }
    }
    
    # Individual planetary correlations
    planets = ['sun', 'jupiter', 'saturn', 'venus', 'mars']
    tep_metrics = ['coherence_mean', 'coherence_median', 'coherence_std']
    
    correlations = {}
    
    for planet in planets:
        planet_corr = {}
        influence_col = f'{planet}_influence'
        
        if influence_col in combined_df.columns:
            for metric in tep_metrics:
                if metric in combined_df.columns:
                    r, p = stats.pearsonr(combined_df[influence_col], combined_df[metric])
                    rho, p_spear = stats.spearmanr(combined_df[influence_col], combined_df[metric])
                    
                    planet_corr[metric] = {
                        'pearson_r': r,
                        'pearson_p': p,
                        'spearman_rho': rho,
                        'spearman_p': p_spear,
                        'n_points': len(combined_df)
                    }
        
        correlations[f'{planet}_influence'] = planet_corr
    
    # KEY DISCOVERY: Stacked planetary influence analysis
    stacked_correlations = {}
    for metric in tep_metrics:
        if metric in combined_df.columns:
            r, p = stats.pearsonr(combined_df['total_planetary_influence'], combined_df[metric])
            rho, p_spear = stats.spearmanr(combined_df['total_planetary_influence'], combined_df[metric])
            
            stacked_correlations[metric] = {
                'pearson_r': r,
                'pearson_p': p,
                'spearman_rho': rho,
                'spearman_p': p_spear,
                'n_points': len(combined_df)
            }
    
    correlations['stacked_planetary_influence'] = stacked_correlations
    
    # Total gravitational influence (including Sun)
    total_correlations = {}
    for metric in tep_metrics:
        if metric in combined_df.columns:
            r, p = stats.pearsonr(combined_df['total_influence'], combined_df[metric])
            rho, p_spear = stats.spearmanr(combined_df['total_influence'], combined_df[metric])
            
            total_correlations[metric] = {
                'pearson_r': r,
                'pearson_p': p,
                'spearman_rho': rho,
                'spearman_p': p_spear,
                'n_points': len(combined_df)
            }
    
    correlations['total_gravitational_influence'] = total_correlations
    results['correlations'] = correlations
    
    # Advanced pattern analysis with smoothing
    min_data_points_for_smoothing = 5 # Minimum data points required for meaningful smoothing

    if len(combined_df) >= min_data_points_for_smoothing:
        window_size = min(31, len(combined_df) // 2 - 1) # Ensure window_size is smaller than data length
        if window_size % 2 == 0: # Ensure window_size is odd
            window_size -= 1
        if window_size < 3: # Minimum window size is 3
            window_size = 3

        poly_order = min(3, window_size - 2) # Ensure poly_order is less than window_size - 1
        if poly_order < 1: # Minimum poly_order is 1
            poly_order = 1

        if window_size > poly_order and window_size >= 3:
            smoothed_stacked = savgol_filter(combined_df['total_planetary_influence'], window_size, poly_order)
            smoothed_coherence_std = savgol_filter(combined_df['coherence_std'], window_size, poly_order)
            
            # Smoothed pattern correlation
            smooth_r, smooth_p = stats.pearsonr(smoothed_stacked, smoothed_coherence_std)
            
            # Cross-correlation analysis for lag detection
            norm_stacked = (smoothed_stacked - np.mean(smoothed_stacked)) / np.std(smoothed_stacked)
            norm_coherence = (smoothed_coherence_std - np.mean(smoothed_coherence_std)) / np.std(smoothed_coherence_std)
            
            cross_corr = correlate(norm_coherence, norm_stacked, mode='full')
            lags = np.arange(-len(norm_stacked) + 1, len(norm_stacked))
            max_corr_idx = np.argmax(np.abs(cross_corr))
            optimal_lag = lags[max_corr_idx]
            max_correlation = cross_corr[max_corr_idx]
            
            results['advanced_pattern_analysis'] = {
                'smoothed_correlation': smooth_r,
                'smoothed_p_value': smooth_p,
                'optimal_lag_days': int(optimal_lag),
                'max_cross_correlation': float(max_correlation),
                'smoothing_window': window_size,
                'pattern_relationship': 'anti_phase' if max_correlation < 0 else 'in_phase'
            }
        else:
            print_status(f"Skipping advanced pattern analysis due to insufficient data points or invalid smoothing parameters: window_size={window_size}, poly_order={poly_order}, data_len={len(combined_df)}", "WARNING")
            results['advanced_pattern_analysis'] = {'status': 'skipped', 'reason': 'insufficient data for smoothing'}
    else:
        print_status(f"Skipping advanced pattern analysis due to insufficient data points ({len(combined_df)} < {min_data_points_for_smoothing})", "WARNING")
        results['advanced_pattern_analysis'] = {'status': 'skipped', 'reason': 'insufficient data points'}

    # Pattern extremes analysis
    stacked_peaks = combined_df[combined_df['total_planetary_influence'] > combined_df['total_planetary_influence'].quantile(0.9)]
    stacked_valleys = combined_df[combined_df['total_planetary_influence'] < combined_df['total_planetary_influence'].quantile(0.1)]
    
    results['pattern_extremes'] = {
        'peak_periods': len(stacked_peaks),
        'valley_periods': len(stacked_valleys),
        'peak_coherence_mean': float(stacked_peaks['coherence_mean'].mean()),
        'valley_coherence_mean': float(stacked_valleys['coherence_mean'].mean()),
        'peak_coherence_std': float(stacked_peaks['coherence_std'].mean()),
        'valley_coherence_std': float(stacked_valleys['coherence_std'].mean()),
        'coherence_mean_difference': float(stacked_peaks['coherence_mean'].mean() - stacked_valleys['coherence_mean'].mean()),
        'coherence_std_difference': float(stacked_peaks['coherence_std'].mean() - stacked_valleys['coherence_std'].mean())
    }
    
    return results

def create_comprehensive_visualization(combined_df: pd.DataFrame, analysis_results: Dict) -> str:
    """
    Create comprehensive visualization with site-consistent theme.
    """
    print_status("Creating comprehensive visualization with site theme...", "INFO")
    
    # Set site-themed style
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'Times', 'DejaVu Serif'],
        'font.size': 11,
        'axes.titlesize': 14,
        'axes.labelsize': 12,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'legend.fontsize': 9,
        'lines.linewidth': 1.5,
        'axes.linewidth': 1.0,
        'grid.color': '#495773',
        'grid.linestyle': '--',
        'grid.linewidth': 0.5,
        'axes.grid': True,
        'figure.facecolor': 'white',
        'text.color': '#220126',
        'axes.labelcolor': '#220126',
        'xtick.color': '#220126',
        'ytick.color': '#220126',
        'axes.titlecolor': '#2D0140'
    })
    
    # Set up the figure with optimal layout
    fig = plt.figure(figsize=(18, 20))
    gs = fig.add_gridspec(4, 1, height_ratios=[1, 1, 1, 1], hspace=0.4, left=0.08, right=0.95)
    
    # Site-themed color scheme
    colors = {
        'mars': '#E74C3C',        # Red for Mars
        'venus': '#F39C12',       # Orange for Venus
        'saturn': '#3498DB',      # Blue for Saturn  
        'jupiter': '#2D0140',     # Site dark purple for Jupiter (dominant)
        'sun': '#F1C40F',        # Yellow for Sun
        'total': '#220126',       # Site primary dark for total
        'temporal': '#4A90C2',    # Site accent blue for temporal
        'secondary': '#495773'    # Site secondary for accents
    }
    
    # Panel 1: Stacked Planetary Gravitational Influences
    ax1 = fig.add_subplot(gs[0, 0])
    
    # Create stacked area chart
    dates = combined_df['date']
    mars_vals = combined_df['mars_influence']
    venus_vals = combined_df['venus_influence'] 
    saturn_vals = combined_df['saturn_influence']
    jupiter_vals = combined_df['jupiter_influence']
    
    ax1.fill_between(dates, 0, mars_vals, alpha=0.8, color=colors['mars'], label='Mars')
    ax1.fill_between(dates, mars_vals, mars_vals + venus_vals, alpha=0.8, color=colors['venus'], label='Venus')
    ax1.fill_between(dates, mars_vals + venus_vals, mars_vals + venus_vals + saturn_vals, 
                     alpha=0.8, color=colors['saturn'], label='Saturn')
    ax1.fill_between(dates, mars_vals + venus_vals + saturn_vals, 
                     mars_vals + venus_vals + saturn_vals + jupiter_vals,
                     alpha=0.8, color=colors['jupiter'], label='Jupiter')
    
    # Add total planetary influence line
    ax1.plot(dates, combined_df['total_planetary_influence'], color=colors['total'], 
             linewidth=2, label='Total Planetary Influence')
    
    ax1.set_ylabel('Gravitational Influence (M_Earth/AU²)', fontsize=12, fontweight='bold')
    ax1.set_title('Stacked Planetary Gravitational Influences on Earth\n' + 
                  'NASA/JPL DE440/441 High-Precision Ephemeris', fontsize=14, fontweight='bold')
    ax1.legend(loc='upper right', fontsize=10)
    ax1.grid(True, alpha=0.3)
    
    # Panel 2: TEP Temporal Field Signatures
    ax2 = fig.add_subplot(gs[1, 0])
    
    # Plot coherence metrics
    ax2_twin = ax2.twinx()
    
    line1 = ax2.plot(dates, combined_df['coherence_mean'], color=colors['temporal'], 
                     linewidth=2, label='Coherence Mean', alpha=0.8)
    line2 = ax2_twin.plot(dates, combined_df['coherence_std'], color=colors['secondary'], 
                          linewidth=2, label='Coherence Variability', alpha=0.8)
    
    ax2.set_ylabel('TEP Coherence Mean', fontsize=12, fontweight='bold', color=colors['temporal'])
    ax2_twin.set_ylabel('TEP Coherence Variability (Std)', fontsize=12, fontweight='bold', color=colors['secondary'])
    ax2.set_title('TEP Temporal Field Signatures from GNSS Clock Correlations\n' +
                  'Phase-Coherent Cross-Spectral Density Analysis', fontsize=14, fontweight='bold')
    
    # Combine legends
    lines1, labels1 = ax2.get_legend_handles_labels()
    lines2, labels2 = ax2_twin.get_legend_handles_labels()
    ax2.legend(lines1 + lines2, labels1 + labels2, loc='upper right', fontsize=10)
    ax2.grid(True, alpha=0.3)
    
    # Panel 3: Pattern Correlation Analysis
    ax3 = fig.add_subplot(gs[2, 0])
    
    # Smoothed patterns for correlation visualization
    min_data_points_for_smoothing = 5 # Minimum data points required for meaningful smoothing
    if len(combined_df) >= min_data_points_for_smoothing:
        window_size = min(31, len(combined_df) // 2 - 1) # Ensure window_size is smaller than data length
        if window_size % 2 == 0: # Ensure window_size is odd
            window_size -= 1
        if window_size < 3: # Minimum window size is 3
            window_size = 3

        poly_order = min(3, window_size - 2) # Ensure poly_order is less than window_size - 1
        if poly_order < 1: # Minimum poly_order is 1
            poly_order = 1

        if window_size > poly_order and window_size >= 3:
            smoothed_stacked = savgol_filter(combined_df['total_planetary_influence'], window_size, poly_order)
            smoothed_coherence_std = savgol_filter(combined_df['coherence_std'], window_size, poly_order)
            
            # Normalize for comparison
            norm_stacked = (smoothed_stacked - np.mean(smoothed_stacked)) / np.std(smoothed_stacked)
            norm_coherence = (smoothed_coherence_std - np.mean(smoothed_coherence_std)) / np.std(smoothed_coherence_std)
            
            ax3.plot(dates, norm_stacked, color=colors['total'], linewidth=3, 
                     label='Normalized Stacked Gravitational Pattern', alpha=0.8)
            ax3.plot(dates, norm_coherence, color=colors['secondary'], linewidth=3, 
                     label='Normalized Temporal Field Pattern', alpha=0.8)
            
            # Add correlation coefficient
            if 'advanced_pattern_analysis' in analysis_results and analysis_results['advanced_pattern_analysis'].get('status') != 'skipped':
                corr_r = analysis_results['advanced_pattern_analysis']['smoothed_correlation']
                corr_p = analysis_results['advanced_pattern_analysis']['smoothed_p_value']
                ax3.text(0.02, 0.95, f'Pattern Correlation: r = {corr_r:.3f}, p = {corr_p:.2e}', 
                         transform=ax3.transAxes, fontsize=12, fontweight='bold', color='#220126',
                         bbox=dict(boxstyle='round,pad=0.4', facecolor='#F8F8FF', 
                                  edgecolor='#2D0140', alpha=0.95, linewidth=1))
            else:
                ax3.text(0.02, 0.95, 'Pattern Correlation: Skipped (insufficient data)', 
                         transform=ax3.transAxes, fontsize=12, fontweight='bold', color='#220126',
                         bbox=dict(boxstyle='round,pad=0.4', facecolor='#F8F8FF', 
                                  edgecolor='#2D0140', alpha=0.95, linewidth=1))
        else:
            ax3.text(0.5, 0.5, 'Insufficient data for smoothing (Panel 3)', transform=ax3.transAxes, 
                     ha='center', va='center', fontsize=12, color='#220126')
            print_status(f"Skipping Panel 3 smoothing due to insufficient data points or invalid smoothing parameters: window_size={window_size}, poly_order={poly_order}, data_len={len(combined_df)}", "WARNING")
    else:
        ax3.text(0.5, 0.5, 'Insufficient data for smoothing (Panel 3)', transform=ax3.transAxes, 
                 ha='center', va='center', fontsize=12, color='#220126')
        print_status(f"Skipping Panel 3 due to insufficient data points ({len(combined_df)} < {min_data_points_for_smoothing})", "WARNING")

    ax3.set_ylabel('Normalized Pattern Amplitude', fontsize=12, fontweight='bold')
    ax3.set_title('Gravitational-Temporal Field Pattern Correlation Analysis\n' +
                  'Smoothed Patterns Reveal Underlying Coupling', fontsize=14, fontweight='bold')
    ax3.legend(loc='upper right', fontsize=10)
    ax3.grid(True, alpha=0.3)
    ax3.axhline(y=0, color='#220126', linestyle='-', alpha=0.8, linewidth=1.5)
    
    # Panel 4: Multi-Window Smoothing Comparison
    ax4 = fig.add_subplot(gs[3, 0])
    
    # Test different smoothing windows
    if len(combined_df) >= min_data_points_for_smoothing:
        smoothing_windows = [60, 90, 120, 180, 240]
        window_colors = ['#E74C3C', '#F39C12', '#3498DB', '#2D0140', '#9B59B6']  # Different colors for each window
        
        correlations_by_window = {}
        
        for i, window in enumerate(smoothing_windows):
            adjusted_window = min(window, len(combined_df) // 2 - 1)
            if adjusted_window % 2 == 0:
                adjusted_window -= 1
            if adjusted_window < 3:
                adjusted_window = 3 # Minimum window size is 3

            poly_order = min(3, adjusted_window - 2)
            if poly_order < 1:
                poly_order = 1 # Minimum poly_order is 1
            
            if adjusted_window > poly_order and adjusted_window >= 3:
                # Apply smoothing
                smoothed_stacked = savgol_filter(combined_df['total_planetary_influence'], adjusted_window, poly_order)
                smoothed_coherence_std = savgol_filter(combined_df['coherence_std'], adjusted_window, poly_order)
                
                # Normalize for comparison
                norm_stacked = (smoothed_stacked - np.mean(smoothed_stacked)) / np.std(smoothed_stacked)
                norm_coherence = (smoothed_coherence_std - np.mean(smoothed_coherence_std)) / np.std(smoothed_coherence_std)
                
                # Calculate correlation
                r, p = stats.pearsonr(smoothed_stacked, smoothed_coherence_std)
                correlations_by_window[window] = {'r': r, 'p': p}
                
                # Plot normalized patterns (offset for visibility)
                offset = i * 0.3
                ax4.plot(dates, norm_stacked + offset, color=window_colors[i], linewidth=2, 
                        alpha=0.8, label=f'Gravitational (w={window}, r={r:.3f})')
                ax4.plot(dates, norm_coherence + offset, color=window_colors[i], linewidth=2, 
                        linestyle='--', alpha=0.6, label=f'Temporal (w={window})')
            else:
                print_status(f"Skipping smoothing window {window} due to insufficient data points or invalid parameters: adjusted_window={adjusted_window}, poly_order={poly_order}, data_len={len(combined_df)}", "WARNING")

        ax4.set_ylabel('Normalized Pattern Amplitude (Offset)', fontsize=12, fontweight='bold')
        ax4.set_title('Multi-Window Smoothing Comparison\n' +
                      'Different Smoothing Windows Reveal Pattern Stability', fontsize=14, fontweight='bold')
        ax4.legend(loc='upper right', fontsize=9, ncol=2)
        ax4.grid(True, alpha=0.3)
        ax4.axhline(y=0, color='#220126', linestyle='-', alpha=0.8, linewidth=1.5)
        
        # Add correlation summary text
        corr_text = "Window Correlations:\n"
        if correlations_by_window:
            for window, corr_data in correlations_by_window.items():
                corr_text += f"w={window}: r={corr_data['r']:.3f}, p={corr_data['p']:.2e}\n"
        else:
            corr_text += "N/A (insufficient data)"

        ax4.text(0.02, 0.95, corr_text, transform=ax4.transAxes, fontsize=10, 
                 fontweight='bold', color='#220126',
                 bbox=dict(boxstyle='round,pad=0.4', facecolor='#F8F8FF', 
                          edgecolor='#2D0140', alpha=0.95, linewidth=1),
                 verticalalignment='top')
    else:
        ax4.text(0.5, 0.5, 'Insufficient data for smoothing (Panel 4)', transform=ax4.transAxes, 
                 ha='center', va='center', fontsize=12, color='#220126')
        print_status(f"Skipping Panel 4 due to insufficient data points ({len(combined_df)} < {min_data_points_for_smoothing})", "WARNING")

    # Format x-axis for all time series plots
    for ax in [ax1, ax2, ax3, ax4]:
        ax.xaxis.set_major_locator(mdates.MonthLocator(interval=6))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        ax.tick_params(axis='x', rotation=45)
    
    # Use subplots_adjust instead of tight_layout for complex subplots
    plt.subplots_adjust(hspace=0.3, wspace=0.3)
    
    # Save the figure
    output_path = PACKAGE_ROOT / 'results/figures/step_4_4_comprehensive_gravitational_temporal_analysis.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close(fig)
    
    # Copy to site figures folder for manuscript
    import shutil
    site_path = PACKAGE_ROOT / 'site/figures/step_4_4_comprehensive_gravitational_temporal_analysis.png'
    shutil.copy2(output_path, site_path)
    
    print_status(f"Comprehensive visualization saved: {output_path}", "INFO")
    print_status(f"Figure synced to site: {site_path}", "INFO")
    return str(output_path)

@ensure_single_instance
def main():
    """
    Main execution function that recreates the correct working analysis.
    """
    print_status("TEP GNSS Analysis Package v0.13 - STEP 4.4: Comprehensive Gravitational-Temporal Field Correlation Analysis", "INFO")
    print_status("\n", "INFO")
    
    # Configuration
    start_date = '2023-01-01'
    end_date = '2025-06-30'
    
    # Generate gravitational data
    print_status(f"Generating high-precision gravitational data from {start_date} to {end_date}...", "INFO")
    
    start = datetime.strptime(start_date, '%Y-%m-%d')
    end = datetime.strptime(end_date, '%Y-%m-%d')
    
    data_list = []
    current_date = start
    
    while current_date <= end:
        gravitational_data = calculate_high_precision_gravitational_influence(current_date)
        
        if gravitational_data:
            data_entry = {'date': current_date}
            data_entry.update(gravitational_data)
            data_list.append(data_entry)
        
        current_date += timedelta(days=1)
        
        # Progress indicator
        if len(data_list) % 100 == 0:
            print_status(f"  Processed {len(data_list)} days...", "INFO")
    
    gravitational_df = pd.DataFrame(data_list)
    print_status(f"Generated gravitational data for {len(gravitational_df)} days", "INFO")
    
    # Extract authentic daily TEP coherence data
    tep_df = extract_real_daily_tep_coherence_data()
    
    # Merge datasets
    print_status("Merging gravitational and temporal field datasets...", "INFO")
    combined_df = pd.merge(gravitational_df, tep_df, on='date', how='inner')
    print_status(f"Combined dataset: {len(combined_df)} days of synchronized data", "INFO")
    
    # Perform comprehensive correlation analysis
    analysis_results = perform_advanced_correlation_analysis(combined_df)
    
    # Create comprehensive visualization
    figure_path = create_comprehensive_visualization(combined_df, analysis_results)
    analysis_results['figure_path'] = figure_path
    
    # Save results
    results_path = PACKAGE_ROOT / 'results/outputs/step_4_4_gravitational_temporal_field_analysis.json'
    safe_json_write(analysis_results, results_path, indent=2)
    
    data_path = PACKAGE_ROOT / 'data/processed/step_4_4_comprehensive_gravitational_temporal_data.csv'
    combined_df.to_csv(data_path, index=False)

    # Export WebGL-ready dataset for Step 17 visualization (no fallbacks)
    export_dir = PACKAGE_ROOT / 'site/data/step_4_4'
    export_dir.mkdir(parents=True, exist_ok=True)

    export_payload = {
        'dates': [d.strftime('%Y-%m-%d') for d in combined_df['date']],
        'total_planetary_influence': combined_df['total_planetary_influence'].tolist(),
        'total_influence': combined_df['total_influence'].tolist(),
        'coherence_mean': combined_df['coherence_mean'].tolist(),
        'coherence_std': combined_df['coherence_std'].tolist(),
        'individual_influences': {
            body: combined_df[f'{body}_influence'].tolist()
            for body in ['sun', 'jupiter', 'saturn', 'venus', 'mars']
        },
        'coherence_count': combined_df['coherence_count'].tolist(),
        'advanced_pattern_analysis': analysis_results.get('advanced_pattern_analysis'),
    }

    export_path = export_dir / 'step_4_4_gravitational_temporal_daily.json'
    safe_json_write(export_payload, export_path)
    
    # Print summary
    print_status("\n" + "=" * 80, "INFO")
    print_status("ANALYSIS COMPLETE - KEY DISCOVERIES", "INFO")
    print_status("=" * 80, "INFO")
    
    stacked_corr = analysis_results['correlations']['stacked_planetary_influence']['coherence_std']
    print_status(f"STACKED GRAVITATIONAL PATTERN CORRELATION: r = {stacked_corr['pearson_r']:.4f}, p = {stacked_corr['pearson_p']:.2e}", "INFO")
    
    if 'advanced_pattern_analysis' in analysis_results and analysis_results['advanced_pattern_analysis'].get('status') != 'skipped':
        smooth_corr = analysis_results['advanced_pattern_analysis']['smoothed_correlation']
        print_status(f"SMOOTHED PATTERN CORRELATION: r = {smooth_corr:.4f}", "INFO")
    else:
        print_status("SMOOTHED PATTERN CORRELATION: Skipped (insufficient data)", "INFO")
    
    print_status(f"DATASET: {len(combined_df)} days", "INFO")
    print_status(f"FIGURE: {figure_path}", "INFO")
    print_status(f"RESULTS: {results_path}", "INFO")
    print_status(f"DATA: {data_path}", "INFO")
    
    print_status("\nKEY DISCOVERY:", "INFO")
    print_status("   The stacked gravitational influence pattern demonstrates significant")
    print_status("   correlation with Earth's temporal field structure, providing")
    print_status("   experimental evidence supporting TEP theory predictions.", "INFO")
    print_status("=" * 80, "INFO")
    
    return analysis_results

if __name__ == "__main__":
    try:
        results = main()
        sys.exit(0 if results.get('success', False) else 1)
    except KeyboardInterrupt:
        print_status("Step 4.4 interrupted by user", "WARNING")
        sys.exit(1)
    except Exception as e:
        print_status(f"Step 4.4 failed - unexpected error: {e}", "ERROR")
        import traceback
        traceback.print_exc()
        sys.exit(1)