#!/usr/bin/env python3
"""
TEP-GNSS Analysis - Exploratory Script
======================================

Generate Binning & Weighting Sensitivity Figure

This script performs a sensitivity analysis to demonstrate the robustness of the
TEP correlation parameters (λ and R²) to different distance binning and model
weighting strategies. It loads the full pair-level correlation data, applies
various analysis configurations, and generates a multi-panel summary figure.

SCIENTIFIC RATIONALE:
====================
A key validation requirement is to show that the primary findings are not artifacts
of arbitrary analysis choices. This script directly addresses this by sweeping
key parameters:
- Binning Strategy: Logarithmic (equal-width in log space), Linear (equal-width),
  and Quantile (equal-count).
- Bin Count: Varies the number of bins to test sensitivity to granularity.
- Weighting Scheme: Tests model fitting robustness to different statistical weights.

The expected outcome is that λ and R² remain stable across these variations,
confirming that the detected exponential correlation is a fundamental property
of the data, not an artifact of the analysis methodology.

Methodology:
1. Load pair-level correlation data for a specified analysis center.
2. Define a matrix of scenarios with different binning schemes, counts, and weights.
3. For each scenario:
   a. Bin the pair-level data according to the specified strategy.
   b. Filter bins with insufficient statistical power.
   c. Fit the standard exponential decay model C(r) = A * exp(-r/λ) + C₀.
   d. Store the resulting λ, R², and their uncertainties.
4. Generate a multi-panel summary plot visualizing the stability of λ and R²
   across all tested scenarios.
5. Save the figure to the `results/figures/exploratory` directory.

"""

import os
import sys
import json
import warnings
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from scipy.optimize import curve_fit
from typing import Dict, List, Tuple, Optional

# Add project root to path to allow imports from utils
PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.append(str(PROJECT_ROOT))

from scripts.utils.logger import print_status
from scripts.utils.config import TEPConfig

warnings.filterwarnings('ignore', category=UserWarning)


def exponential_model(r: np.ndarray, A: float, lambda_km: float, C0: float) -> np.ndarray:
    """Standard exponential decay model."""
    return A * np.exp(-r / lambda_km) + C0


def fit_exponential_model(distances: np.ndarray, coherences: np.ndarray, weights: Optional[np.ndarray] = None) -> Dict:
    """Fit the exponential model to binned data and return key parameters."""
    if len(distances) < 5:
        return {'success': False, 'error': 'Insufficient data for fit'}

    try:
        bounds = ([0.0, 100.0, -1.0], [2.0, 20000.0, 1.0])
        p0 = [0.1, 4000, 0]

        popt, pcov = curve_fit(
            exponential_model,
            distances,
            coherences,
            p0=p0,
            sigma=1.0 / weights if weights is not None else None,
            bounds=bounds,
            maxfev=5000,
            absolute_sigma=True if weights is not None else False
        )

        A, lambda_km, C0 = popt
        perr = np.sqrt(np.diag(pcov))
        
        residuals = coherences - exponential_model(distances, *popt)
        
        if weights is not None:
            chi2 = np.sum((residuals * weights)**2)
            dof = len(distances) - len(popt)
            r_squared = 1 - (np.sum(weights**2 * residuals**2) / np.sum(weights**2 * (coherences - np.average(coherences, weights=weights))**2))
        else:
            chi2 = np.sum(residuals**2)
            dof = len(distances) - len(popt)
            r_squared = 1 - (np.sum(residuals**2) / np.sum((coherences - np.mean(coherences))**2))


        return {
            'success': True,
            'lambda': lambda_km,
            'lambda_err': perr[1],
            'r_squared': r_squared,
            'A': A,
            'C0': C0,
            'chi2_reduced': chi2 / dof if dof > 0 else np.inf
        }

    except (RuntimeError, ValueError) as e:
        return {'success': False, 'error': str(e)}


def perform_binning(df: pd.DataFrame, strategy: str, n_bins: int, min_dist: float, max_dist: float) -> Optional[pd.DataFrame]:
    """Apply a specified binning strategy to the pair-level data."""
    if strategy == 'log':
        edges = np.logspace(np.log10(min_dist), np.log10(max_dist), n_bins + 1)
    elif strategy == 'linear':
        edges = np.linspace(min_dist, max_dist, n_bins + 1)
    elif strategy == 'quantile':
        edges = np.percentile(df['dist_km'], np.linspace(0, 100, n_bins + 1))
        # Ensure edges are unique
        edges = np.unique(edges)
        if len(edges) < n_bins / 2: # not enough unique edges
            return None
    else:
        raise ValueError(f"Unknown binning strategy: {strategy}")

    df = df.copy()
    df['bin'] = pd.cut(df['dist_km'], bins=edges, include_lowest=True, right=False)
    
    binned = df.groupby('bin', observed=False).agg(
        mean_dist=('dist_km', 'mean'),
        mean_coh=('coherence', 'mean'),
        count=('coherence', 'size')
    ).dropna().reset_index()

    return binned[binned['count'] >= TEPConfig.get_int('TEP_MIN_BIN_COUNT', 100)]


def run_sensitivity_analysis(pair_df: pd.DataFrame) -> pd.DataFrame:
    """Run the full sensitivity analysis across all defined scenarios."""
    scenarios = []
    # 1. Bin Count Sweep (Logarithmic Binning, Standard Weighting)
    for n_bins in [25, 40, 80]:
        scenarios.append({'strategy': 'log', 'n_bins': n_bins, 'weighting': 'count'})

    # 2. Binning Strategy Sweep (40 Bins, Standard Weighting)
    for strategy in ['linear', 'quantile']:
        scenarios.append({'strategy': strategy, 'n_bins': 40, 'weighting': 'count'})

    # 3. Weighting Scheme Sweep (Logarithmic Binning, 40 Bins)
    for weighting in ['sqrt_count', 'none']:
        scenarios.append({'strategy': 'log', 'n_bins': 40, 'weighting': weighting})

    results = []
    min_dist = 50.0
    max_dist = TEPConfig.get_float('TEP_MAX_DISTANCE_KM', 13000)

    for i, params in enumerate(scenarios):
        print_status(f"Running scenario {i+1}/{len(scenarios)}: {params['strategy']} bins={params['n_bins']}, weights={params['weighting']}", "PROCESS")
        
        binned_df = perform_binning(pair_df, params['strategy'], params['n_bins'], min_dist, max_dist)
        
        if binned_df is None or binned_df.empty:
            print_status("  -> Scenario skipped (insufficient data after binning)", "WARNING")
            continue

        weights = None
        if params['weighting'] == 'count':
            weights = binned_df['count'].values
        elif params['weighting'] == 'sqrt_count':
            weights = np.sqrt(binned_df['count'].values)

        fit_result = fit_exponential_model(binned_df['mean_dist'].values, binned_df['mean_coh'].values, weights)
        
        if fit_result['success']:
            results.append({
                'strategy': params['strategy'],
                'n_bins': params['n_bins'],
                'weighting': params['weighting'],
                'lambda': fit_result['lambda'],
                'lambda_err': fit_result['lambda_err'],
                'r_squared': fit_result['r_squared']
            })
        else:
            print_status(f"  -> Fit failed: {fit_result.get('error')}", "ERROR")
            
    return pd.DataFrame(results)


def plot_sensitivity_results(results_df: pd.DataFrame, ac: str, output_path: Path):
    """Generate and save the multi-panel sensitivity plot."""
    if results_df.empty:
        print_status("No results to plot.", "WARNING")
        return
        
    sns.set_theme(style="whitegrid", context="paper")
    fig = plt.figure(figsize=(12, 10))
    gs = fig.add_gridspec(3, 2, height_ratios=(2, 2, 1))
    fig.suptitle(f'Binning & Weighting Sensitivity Analysis ({ac.upper()})', fontsize=18, weight='bold')

    # Base parameters for comparison line
    base_result = results_df[(results_df['strategy'] == 'log') & (results_df['n_bins'] == 40) & (results_df['weighting'] == 'count')]
    base_lambda = base_result['lambda'].iloc[0] if not base_result.empty else None
    base_r2 = base_result['r_squared'].iloc[0] if not base_result.empty else None

    # --- Panel 1: Bin Count Sensitivity ---
    ax1 = fig.add_subplot(gs[0, 0])
    df1 = results_df[(results_df['strategy'] == 'log') & (results_df['weighting'] == 'count')]
    sns.stripplot(x='n_bins', y='lambda', data=df1, ax=ax1, size=10, jitter=False, palette='viridis')
    if base_lambda:
        ax1.axhline(base_lambda, ls='--', color='gray', label=f'Baseline λ ({base_lambda:.0f} km)')
    ax1.set_title('λ vs. Bin Count (Logarithmic Binning)', weight='bold')
    ax1.set_xlabel('Number of Bins')
    ax1.set_ylabel('Correlation Length λ (km)')
    ax1.legend()

    ax2 = fig.add_subplot(gs[0, 1])
    sns.stripplot(x='n_bins', y='r_squared', data=df1, ax=ax2, size=10, jitter=False, palette='viridis')
    if base_r2:
        ax2.axhline(base_r2, ls='--', color='gray', label=f'Baseline R² ({base_r2:.3f})')
    ax2.set_title('R² vs. Bin Count (Logarithmic Binning)', weight='bold')
    ax2.set_xlabel('Number of Bins')
    ax2.set_ylabel('Goodness of Fit (R²)')
    ax2.set_ylim(bottom=max(0, df1['r_squared'].min() - 0.05))
    ax2.legend()

    # --- Panel 2: Binning Strategy Sensitivity ---
    ax3 = fig.add_subplot(gs[1, 0])
    df2 = results_df[(results_df['n_bins'] == 40) & (results_df['weighting'] == 'count')]
    sns.stripplot(x='strategy', y='lambda', data=df2, ax=ax3, size=10, jitter=False, palette='plasma')
    if base_lambda:
        ax3.axhline(base_lambda, ls='--', color='gray')
    ax3.set_title('λ vs. Binning Strategy (40 Bins)', weight='bold')
    ax3.set_xlabel('Binning Strategy')
    ax3.set_ylabel('Correlation Length λ (km)')

    ax4 = fig.add_subplot(gs[1, 1])
    sns.stripplot(x='strategy', y='r_squared', data=df2, ax=ax4, size=10, jitter=False, palette='plasma')
    if base_r2:
        ax4.axhline(base_r2, ls='--', color='gray')
    ax4.set_title('R² vs. Binning Strategy (40 Bins)', weight='bold')
    ax4.set_xlabel('Binning Strategy')
    ax4.set_ylabel('Goodness of Fit (R²)')
    ax4.set_ylim(bottom=max(0, df2['r_squared'].min() - 0.05))

    # --- Panel 3: Weighting Scheme Sensitivity ---
    ax5 = fig.add_subplot(gs[2, :]) # Span both columns
    df3 = results_df[(results_df['strategy'] == 'log') & (results_df['n_bins'] == 40)]
    sns.stripplot(x='weighting', y='lambda', data=df3, ax=ax5, size=10, jitter=False, palette='magma')
    if base_lambda:
        ax5.axhline(base_lambda, ls='--', color='gray')
    ax5.set_title('λ vs. Weighting Scheme (Log Binning, 40 Bins)', weight='bold')
    ax5.set_xlabel('Weighting Scheme')
    ax5.set_ylabel('Correlation Length λ (km)')

    plt.tight_layout(rect=[0, 0, 1, 0.96])
    plt.savefig(output_path, dpi=300)
    print_status(f"Sensitivity plot saved to: {output_path}", "SUCCESS")
    plt.close(fig)


def main():
    """Main execution function."""
    print_status("Starting Binning & Weighting Sensitivity Analysis", "INFO")
    
    # Use the largest dataset for robust analysis
    analysis_center = "code" 
    
    # Find the consolidated pair-level data file
    pair_data_dir = PROJECT_ROOT / "results" / "tmp"
    pair_files = list(pair_data_dir.glob(f"step_2_0_pairs_{analysis_center}_tep_band.csv"))
    
    if not pair_files:
        print_status(f"FATAL: Consolidated pair-level data not found for '{analysis_center}'.", "ERROR")
        print_status("Please run Step 2.0 with `TEP_WRITE_PAIR_LEVEL=1` enabled.", "ERROR")
        sys.exit(1)

    pair_data_path = pair_files[0]
    print_status(f"Loading pair-level data from: {pair_data_path}", "INFO")
    
    try:
        # Load the data, which might be large
        pair_df = pd.read_csv(pair_data_path, usecols=['dist_km', 'plateau_phase'])
        pair_df.dropna(inplace=True)
        
        # Calculate coherence from plateau_phase
        pair_df['coherence'] = np.cos(pair_df['plateau_phase'])

        print_status(f"Loaded {len(pair_df):,} valid pairs for analysis.", "SUCCESS")
        
    except Exception as e:
        print_status(f"Error loading data: {e}", "FATAL")
        sys.exit(1)

    # Run the analysis
    results_df = run_sensitivity_analysis(pair_df)
    
    # Plot the results
    output_dir = PROJECT_ROOT / "results" / "figures" / "exploratory"
    output_dir.mkdir(exist_ok=True)
    output_path = output_dir / "step_x_binning_sensitivity_analysis.png"
    
    plot_sensitivity_results(results_df, analysis_center, output_path)
    
    print_status("Sensitivity analysis complete.", "SUCCESS")


if __name__ == "__main__":
    main()
